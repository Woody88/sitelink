# callout-detection > 2026-01-20 4:20am
https://universe.roboflow.com/plan-detection/callout-detection

Provided by a Roboflow user
License: CC BY 4.0

