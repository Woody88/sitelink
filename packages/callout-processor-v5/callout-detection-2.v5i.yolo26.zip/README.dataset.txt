# callout-detection-2 > 2026-01-22 2:49am
https://universe.roboflow.com/plan-detection/callout-detection-2

Provided by a Roboflow user
License: CC BY 4.0

