# callout-detection > 2026-01-22 1:34am
https://universe.roboflow.com/plan-detection/callout-detection

Provided by a Roboflow user
License: CC BY 4.0

